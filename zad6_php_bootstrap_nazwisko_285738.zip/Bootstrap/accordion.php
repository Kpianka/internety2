<?php

$text = file_get_contents("dowcipy.txt");

$titles = [];
$texts = [];

preg_match_all('/==(.+?)==\s*(.*?)((?==)|$)/s', $text, $matches, PREG_SET_ORDER);

foreach ($matches as $key => $match) {
    $titles[] = $match[1];
    $texts[] = nl2br($match[2]);
}
echo '<div class="accordion" id="accordionPanelsStayOpenExample">';
for ($i = 0; $i < count($titles); $i++) {
    echo '<div class="accordion-item">';
    echo '<h2 class="accordion-header" id="panelsStayOpen-heading' . $i . '">';
    echo '<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse' . $i . '" aria-expanded="false" aria-controls="panelsStayOpen-collapse' . $i . '">';
    echo '<p>' . $titles[$i] . '</p>';
    echo '</button>';
    echo '</h2>';
    echo '<div id="panelsStayOpen-collapse' . $i . '" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-heading' . $i . '">';
    echo '<div class="accordion-body">';
    echo '<p>' . $texts[$i] . '</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}
echo '</div>';

?>
