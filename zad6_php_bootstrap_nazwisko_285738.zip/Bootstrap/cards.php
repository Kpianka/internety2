<?php

$text = file_get_contents("dowcipy.txt");

$titles = [];
$texts = [];

preg_match_all('/==(.+?)==\s*(.*?)((?==)|$)/s', $text, $matches, PREG_SET_ORDER);

foreach ($matches as $match) {
    $titles[] = $match[1];
    $texts[] = nl2br($match[2]);
}

foreach ($matches as $key => $match) {
    echo '<div class="card" style="margin:5px">';
    echo '<div class="card-header">';
    echo '<h5 class="card-title">' . $titles[$key] . '</h5>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<p class="card-text">' . $texts[$key] . '</p>';
    echo '</div>';
    echo '</div>';
}

?>
