<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dowcipy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css" /> 
</head>
<body>
    <div class="container">
        <div class="row justify-content-center mb-3" style="padding-left: 360px;">
            <div class="col-md-8">
                <div class="btn-group" role="group" aria-label="Tryb wyświetlania">
                    <button type="button" class="btn btn-primary" onclick="showCards()">Karty</button>
                    <button type="button" class="btn btn-primary" onclick="showAccordion()">Akordeon</button>
                    <button type="button" class="btn btn-primary" onclick="showCarousel()">Karuzela</button>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div id="cards" class="jokes-box">
                    <?php include 'cards.php'; ?>
                </div>
                <div id="accordion" class="jokes-box d-none">
                    <?php include 'accordion.php'; ?>
                </div>
                <div id="carousel" class="jokes-box d-none">
                    <?php include 'carousel.php'; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showCards() {
            document.getElementById('cards').classList.remove('d-none');
            document.getElementById('accordion').classList.add('d-none');
            document.getElementById('carousel').classList.add('d-none');
        }

        function showAccordion() {
            document.getElementById('cards').classList.add('d-none');
            document.getElementById('accordion').classList.remove('d-none');
            document.getElementById('carousel').classList.add('d-none');
        }

        function showCarousel() {
            document.getElementById('cards').classList.add('d-none');
            document.getElementById('accordion').classList.add('d-none');
            document.getElementById('carousel').classList.remove('d-none');
        }
    </script>
</body>
</html>
