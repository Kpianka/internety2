<?php

$text = file_get_contents("dowcipy.txt");

$titles = [];
$texts = [];

preg_match_all('/==(.+?)==\s*(.*?)((?==)|$)/s', $text, $matches, PREG_SET_ORDER);

foreach ($matches as $key => $match) {
    $titles[] = $match[1];
    $texts[] = nl2br($match[2]);
}

echo '<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">';
echo '<div class="carousel-indicators">';
for ($i = 0; $i < count($titles); $i++) {
    echo '<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="' . $i . '" ' . ($i === 0 ? 'class="active" ' : '') . 'aria-current="true" aria-label="Slide' . $i . '"></button>';
}
echo '</div>';
echo '<div class="carousel-inner">';
for ($i = 0; $i < count($titles); $i++) {
    echo '<div class="carousel-item ' . ($i === 0 ? 'active' : '') . '">';
    echo '<img src="./grey.png" class="d-block w-100">';
    echo '<div class="carousel-caption d-none d-md-block">';
    echo '<h5>' . $titles[$i] . '</h5>';
    echo '<p>' . $texts[$i] . '</p>';
    echo '</div>';
    echo '</div>';
}
echo '</div>';
echo '</div>';

?>
